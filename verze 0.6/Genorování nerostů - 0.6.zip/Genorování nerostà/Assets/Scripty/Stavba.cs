﻿using UnityEngine;
using System.Collections;

public class Stavba : MonoBehaviour {

	public GameObject Stavba_ikonka;
	public Object muj;
	public Transform hlavni;


	void Update ()
	{
		Stavime ();
	}
	public void Stavime()
	{
		if (Input.GetButton("Fire1")==true&& Time.time > 10)
		{
			/*float moveHorizontal = Input.mousePosition.x;
			float moveVertical = Input.mousePosition.z;
			Vector3 position = new Vector3(moveHorizontal, 0.0f, moveVertical);*/
		

				float moveHorizontal = Input.mousePosition.x;
				Vector3 position = new Vector3(moveHorizontal, 0.0f, 0.0f);
				Instantiate(muj, position, hlavni.rotation);
		}
	}
}
