﻿using UnityEngine;
using System.Collections;

	public class Pohyb : MonoBehaviour
	{
	public float rychlost;
		void Start()
		{
			
		}
		void FixedUpdate(){
			float PohybHorizontalne = Input.GetAxis("Horizontal");
			float PohybVerticalne = Input.GetAxis("Vertical");
			Vector3 pohyb = new Vector3 (0.0f, 0.0f, PohybVerticalne);
		if (transform.position.z > 69) {
			transform.position = transform.position+pohyb;
		}else
			transform.position = transform.position-pohyb;
		}
	}
	

