﻿using UnityEngine;
using System.Collections;

namespace AssemblyCSharp
{
	public class ZobrazObjekty : MonoBehaviour
	{
		public GameObject[] Objekty;
			void OnGUI(){
			foreach (GameObject go in Objekty) {
				bool active = GUILayout.Toggle (go.activeSelf, go.name);
				if (active != go.activeSelf)
					go.SetActive (active);
			}
		
		}
	}
}

