﻿using UnityEngine;
using System.Collections;

public class zily_chovani : MonoBehaviour {

	public string druh;
	public int mocnost_zily;
	public bool objeven;
}
