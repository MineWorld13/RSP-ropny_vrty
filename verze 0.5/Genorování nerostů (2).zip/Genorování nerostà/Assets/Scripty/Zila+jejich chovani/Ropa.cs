﻿using UnityEngine;
using System.Collections;

public class Ropa : MonoBehaviour {

	public string druh;
	public float cenaT; //bude se v prubehu casu menit
	[Range(0,100)]
	public int vyteznost; //v procentech a zavysi na pouzite technologii

	public Ropa()
	{
		druh="ropa";
		cenaT = 100;
			
	}


}
