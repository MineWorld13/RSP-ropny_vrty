﻿using UnityEngine;
using System.Collections;

public class BuildingPlacement : MonoBehaviour {
	private PlaceableBuildings placeablebulding;
	private Transform currentBuilding;
	private bool postaveno;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (currentBuilding != null && !postaveno) {
			Vector3 m = Input.mousePosition;
			if(currentBuilding.gameObject.CompareTag("vez"))
				currentBuilding.position = new Vector3 (m.x*(-1)+530, 0.0f,  -465.5f);
			else
				currentBuilding.position = new Vector3 (m.x*(-1)+530, 0.0f,  -430);
			if (Input.GetMouseButtonDown (0)) {
				if (LegalniPozice ()) {
					postaveno = true;
				}
			}
		}
		
	}
	bool LegalniPozice(){
		if (placeablebulding.kolidory.Count > 0) {
			return false;
		}
		return true;
	}

	public void SetItem(GameObject b){
		postaveno = false;
		currentBuilding = ((GameObject)Instantiate (b)).transform;
		placeablebulding = currentBuilding.GetComponent<PlaceableBuildings> ();

	}
}
