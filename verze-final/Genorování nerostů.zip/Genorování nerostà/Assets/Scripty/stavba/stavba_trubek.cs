﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stavba_trubek : MonoBehaviour {
	public Object trubka;
	public Object hlava;
	public Transform plus;
	int i=45;
	GameObject huba;

	public void ClickBT_Plus()
	{
		Vector3 pos = new Vector3(plus.position.x,0,plus.position.z+i);
		Instantiate(trubka, pos, Quaternion.identity);
		if (i == 45) {
			Vector3 pos1 = new Vector3 (plus.position.x, 0, plus.position.z + i * 2);
			huba = Instantiate (hlava, pos1, plus.rotation) as GameObject;
		} 
		else
		{
			Vector3 pos2 = new Vector3 (plus.position.x, 0, plus.position.z + i+45);
			huba.transform.position=pos2;
		}
		i = i+45;
		
	}

}
