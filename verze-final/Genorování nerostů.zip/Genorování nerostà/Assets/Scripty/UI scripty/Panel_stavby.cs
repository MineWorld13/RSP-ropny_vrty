﻿using UnityEngine;
using System.Collections;

public class Panel_stavby : MonoBehaviour {

	public GameObject UIpanel;
	int i=0;
	public void ClickBT_Stavby()
	{
		if (i == 0) {
			UIpanel.SetActive (true);
			i++;
		}
		else
		{
			UIpanel.SetActive (false);
			i--;
		}
	}
}
