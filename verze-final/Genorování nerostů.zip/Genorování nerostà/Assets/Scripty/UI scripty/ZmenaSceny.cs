﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

namespace AssemblyCSharp
{
	public class ZmenaSceny : MonoBehaviour
	{
		bool zobrazDialog = true;
		public GUIStyle buttonback;

		public void zmenasceny(int scena)
		{
			SceneManager.LoadScene (scena);
		}
	}
}

