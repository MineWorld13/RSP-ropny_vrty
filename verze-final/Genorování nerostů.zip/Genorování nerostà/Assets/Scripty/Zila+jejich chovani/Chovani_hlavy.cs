﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chovani_hlavy : MonoBehaviour {

	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag("ropa")) {
			Debug.Log("funguje");
			penize prachy = GetComponent<penize> ();
			prachy.zmena_penez (1000);
			other.gameObject.SetActive(false);
		}
		else
			Debug.Log("NE");
	}
}
