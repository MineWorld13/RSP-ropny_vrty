﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class penize : MonoBehaviour {

	public GameObject prachy;
	public int stav_penez=50000;
	Text text;

	void Start () {
		text = prachy.GetComponent<Text>();
		text.text = stav_penez.ToString ();
	}

	public void zmena_penez(int kolik)
	{
		stav_penez=stav_penez+kolik;
		Update ();
	}

	void Update()
	{
		text.text = stav_penez.ToString ();
	}
}
