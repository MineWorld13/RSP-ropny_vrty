﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Mesh_generator : MonoBehaviour {


	public SquareGrid squareGrid;
	List<Vector3> vertices;
	List<int> triangles;

	public Object zila_objekt;
	public Transform zilaspawn;
	

	public void GenerateMesh(int[,] map, float squareSize) {
		squareGrid = new SquareGrid(map, squareSize);



		vertices = new List<Vector3>();
		triangles = new List<int>();
		
		for (int x = 0; x < squareGrid.squares.GetLength(0); x ++) {
			for (int y = 0; y < squareGrid.squares.GetLength(1); y ++) {
				TriangulateSquare(squareGrid.squares[x,y]);

			}
		}



		Mesh mesh = new Mesh();
		GetComponent<MeshFilter>().mesh = mesh;
		
		mesh.vertices = vertices.ToArray();
		mesh.triangles = triangles.ToArray();
		mesh.RecalculateNormals();
	}

	void Skryj(GameObject nerost)
	{
		nerost.SetActive (false);
	}

	void Taguj(GameObject ctverecek)
	{
		ctverecek.tag="ropa";
	}

	void TriangulateSquare(Square square) {
		switch (square.configuration) {
		case 0:
			break;
			
			// 1 points:
		case 1:
			//MeshFromPoints(square.centreBottom, square.bottomLeft, square.centreLeft);
			Vector3 pos1 = new Vector3 (square.topLeft.position.x, 0, square.topLeft.position.z);
			GameObject jedna = Instantiate (zila_objekt, pos1, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite1 = jedna.AddComponent<SpriteRenderer> ();
			mujsprite1.sprite = Resources.Load<Sprite> ("ropa/jedna");
			Taguj (jedna);
			//Skryj(jedna);
			break;
		case 2:
			//MeshFromPoints(square.centreRight, square.bottomRight, square.centreBottom);
			Vector3 pos2 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject dva = Instantiate(zila_objekt, pos2, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite2 = dva.AddComponent<SpriteRenderer>();
			mujsprite2.sprite= Resources.Load<Sprite>("ropa/dva");
			//Skryj(dva);
			Taguj (dva);
			break;
		case 4:
			//MeshFromPoints(square.centreTop, square.topRight, square.centreRight);
			Vector3 pos4 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject ctyry = Instantiate(zila_objekt, pos4, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite4 = ctyry.AddComponent<SpriteRenderer>();
			mujsprite4.sprite= Resources.Load<Sprite>("ropa/ctyry");
			//Skryj(ctyry);
			Taguj (ctyry);
			break;
		case 8:
			//MeshFromPoints(square.topLeft, square.centreTop, square.centreLeft);
			Vector3 pos8 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject osm = Instantiate(zila_objekt, pos8, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite8 = osm.AddComponent<SpriteRenderer>();
			mujsprite8.sprite= Resources.Load<Sprite>("ropa/osm");
			//Skryj(osm);
			Taguj (osm);
			break;
			
			// 2 points:
		case 3:
			//MeshFromPoints(square.centreRight, square.bottomRight, square.bottomLeft, square.centreLeft);
			Vector3 pos3 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject tri = Instantiate(zila_objekt, pos3, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite3 = tri.AddComponent<SpriteRenderer>();
			mujsprite3.sprite= Resources.Load<Sprite>("ropa/tri");
			//Skryj(tri);
			Taguj (tri);
			break;
		case 6:
			//MeshFromPoints(square.centreTop, square.topRight, square.bottomRight, square.centreBottom);
			Vector3 pos6 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject sest = Instantiate(zila_objekt, pos6, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite6 = sest.AddComponent<SpriteRenderer>();
			mujsprite6.sprite= Resources.Load<Sprite>("ropa/sest");
			//Skryj(sest);
			Taguj (sest);
			break;
		case 9:
			//MeshFromPoints(square.topLeft, square.centreTop, square.centreBottom, square.bottomLeft);
			Vector3 pos9 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject devet = Instantiate(zila_objekt, pos9, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite9 = devet.AddComponent<SpriteRenderer>();
			mujsprite9.sprite= Resources.Load<Sprite>("ropa/devet");
			//Skryj(devet);
			Taguj (devet);
			break;
		case 12:
			//MeshFromPoints(square.topLeft, square.topRight, square.centreRight, square.centreLeft);
			Vector3 pos12 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject dvanact = Instantiate(zila_objekt, pos12, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite12 = dvanact.AddComponent<SpriteRenderer>();
			mujsprite12.sprite= Resources.Load<Sprite>("ropa/dvanact");
			//Skryj(dvanact);
			Taguj (dvanact);
			break;
		case 5:
			//MeshFromPoints(square.centreTop, square.topRight, square.centreRight, square.centreBottom, square.bottomLeft, square.centreLeft);
			Vector3 pos5 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject pet = Instantiate(zila_objekt, pos5, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite5 = pet.AddComponent<SpriteRenderer>();
			mujsprite5.sprite= Resources.Load<Sprite>("ropa/pet");
			//Skryj(pet);
			Taguj (pet);
			break;
		case 10:
			//MeshFromPoints(square.topLeft, square.centreTop, square.centreRight, square.bottomRight, square.centreBottom, square.centreLeft);
			Vector3 pos10 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject deset = Instantiate(zila_objekt, pos10, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite10 = deset.AddComponent<SpriteRenderer>();
			mujsprite10.sprite= Resources.Load<Sprite>("ropa/deset");
			//Skryj(deset);
			Taguj (deset);
			break;
			
			// 3 point:
		case 7:
			//MeshFromPoints(square.centreTop, square.topRight, square.bottomRight, square.bottomLeft, square.centreLeft);
			Vector3 pos7 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject sedm = Instantiate(zila_objekt, pos7, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite7 = sedm.AddComponent<SpriteRenderer>();
			mujsprite7.sprite= Resources.Load<Sprite>("ropa/sedm");
			//Skryj(sedm);
			Taguj (sedm);
			break;
		case 11:
			//MeshFromPoints(square.topLeft, square.centreTop, square.centreRight, square.bottomRight, square.bottomLeft);
			Vector3 pos11 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject jedenact = Instantiate(zila_objekt, pos11, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite11 = jedenact.AddComponent<SpriteRenderer>();
			mujsprite11.sprite= Resources.Load<Sprite>("ropa/jedenact");
			//Skryj(jedenact);
			Taguj (jedenact);
			break;
		case 13:
			//MeshFromPoints(square.topLeft, square.topRight, square.centreRight, square.centreBottom, square.bottomLeft);
			Vector3 pos13 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject trinact = Instantiate(zila_objekt, pos13, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite13 = trinact.AddComponent<SpriteRenderer>();
			mujsprite13.sprite= Resources.Load<Sprite>("ropa/trinact");
			//Skryj(trinact);
			Taguj (trinact);
			break;
		case 14:
			//MeshFromPoints(square.topLeft, square.topRight, square.bottomRight, square.centreBottom, square.centreLeft);
			Vector3 pos14 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject ctrnact = Instantiate(zila_objekt, pos14, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite14 = ctrnact.AddComponent<SpriteRenderer>();
			mujsprite14.sprite= Resources.Load<Sprite>("ropa/ctrnact");
			//Skryj(ctrnact);
			Taguj (ctrnact);
			break;
			
			// 4 point:
		case 15:
			//MeshFromPoints(square.topLeft, square.topRight, square.bottomRight, square.bottomLeft);
			Vector3 pos15 = new Vector3(square.topLeft.position.x,0,square.topLeft.position.z);
			GameObject patnact = Instantiate(zila_objekt, pos15, zilaspawn.rotation) as GameObject;
			SpriteRenderer mujsprite15 = patnact.AddComponent<SpriteRenderer>();
			mujsprite15.sprite= Resources.Load<Sprite>("ropa/patnact");
			//Skryj(patnact);
			Taguj (patnact);
			break;
		}
	}
	
	void MeshFromPoints(params Node[] points) {
		AssignVertices(points);
		
		if (points.Length >= 3)
			CreateTriangle(points[0], points[1], points[2]);
		if (points.Length >= 4)
			CreateTriangle(points[0], points[2], points[3]);
		if (points.Length >= 5) 
			CreateTriangle(points[0], points[3], points[4]);
		if (points.Length >= 6)
			CreateTriangle(points[0], points[4], points[5]);
	}
	
	void AssignVertices(Node[] points) {
		for (int i = 0; i < points.Length; i ++) {
			if (points[i].vertexIndex == -1) {
				points[i].vertexIndex = vertices.Count;
				vertices.Add(points[i].position);
			}
		}
	}
	
	void CreateTriangle(Node a, Node b, Node c) {
		triangles.Add(a.vertexIndex);
		triangles.Add(b.vertexIndex);
		triangles.Add(c.vertexIndex);
	}
	
	void OnDrawGizmos() {
		/*
        if (squareGrid != null) {
            for (int x = 0; x < squareGrid.squares.GetLength(0); x ++) {
                for (int y = 0; y < squareGrid.squares.GetLength(1); y ++) {
                    Gizmos.color = (squareGrid.squares[x,y].topLeft.active)?Color.black:Color.white;
                    Gizmos.DrawCube(squareGrid.squares[x,y].topLeft.position, Vector3.one * .4f);
                    Gizmos.color = (squareGrid.squares[x,y].topRight.active)?Color.black:Color.white;
                    Gizmos.DrawCube(squareGrid.squares[x,y].topRight.position, Vector3.one * .4f);
                    Gizmos.color = (squareGrid.squares[x,y].bottomRight.active)?Color.black:Color.white;
                    Gizmos.DrawCube(squareGrid.squares[x,y].bottomRight.position, Vector3.one * .4f);
                    Gizmos.color = (squareGrid.squares[x,y].bottomLeft.active)?Color.black:Color.white;
                    Gizmos.DrawCube(squareGrid.squares[x,y].bottomLeft.position, Vector3.one * .4f);
                    Gizmos.color = Color.grey;
                    Gizmos.DrawCube(squareGrid.squares[x,y].centreTop.position, Vector3.one * .15f);
                    Gizmos.DrawCube(squareGrid.squares[x,y].centreRight.position, Vector3.one * .15f);
                    Gizmos.DrawCube(squareGrid.squares[x,y].centreBottom.position, Vector3.one * .15f);
                    Gizmos.DrawCube(squareGrid.squares[x,y].centreLeft.position, Vector3.one * .15f);
                }
            }
        }
*/
	}
	
	public class SquareGrid {
		public Square[,] squares;
		
		public SquareGrid(int[,] map, float squareSize) {
			int nodeCountX = map.GetLength(0);
			int nodeCountY = map.GetLength(1);
			float mapWidth = nodeCountX * squareSize;
			float mapHeight = nodeCountY * squareSize;
			
			ControlNode[,] controlNodes = new ControlNode[nodeCountX,nodeCountY];
			
			for (int x = 0; x < nodeCountX; x ++) {
				for (int y = 0; y < nodeCountY; y ++) {
					Vector3 pos = new Vector3(-mapWidth/2 + x * squareSize + squareSize/2, 0, -mapHeight/2 + y * squareSize + squareSize/2);
					controlNodes[x,y] = new ControlNode(pos,map[x,y] == 1, squareSize);
				}
			}
			
			squares = new Square[nodeCountX -1,nodeCountY -1];
			for (int x = 0; x < nodeCountX-1; x ++) {
				for (int y = 0; y < nodeCountY-1; y ++) {
					squares[x,y] = new Square(controlNodes[x,y+1], controlNodes[x+1,y+1], controlNodes[x+1,y], controlNodes[x,y]);
				}
			}
			
		}
	}
	
	public class Square {
		
		public ControlNode topLeft, topRight, bottomRight, bottomLeft;
		public Node centreTop, centreRight, centreBottom, centreLeft;
		public int configuration;
		
		public Square (ControlNode _topLeft, ControlNode _topRight, ControlNode _bottomRight, ControlNode _bottomLeft) {
			topLeft = _topLeft;
			topRight = _topRight;
			bottomRight = _bottomRight;
			bottomLeft = _bottomLeft;
			
			centreTop = topLeft.right;
			centreRight = bottomRight.above;
			centreBottom = bottomLeft.right;
			centreLeft = bottomLeft.above;
			
			if (!topLeft.active)
				configuration += 8;
			if (!topRight.active)
				configuration += 4;
			if (!bottomRight.active)
				configuration += 2;
			if (!bottomLeft.active)
				configuration += 1;
		}
	}
	
	public class Node {
		public Vector3 position;
		public int vertexIndex = -1;
		
		public Node(Vector3 _pos) {
			position = _pos;
		}
	}
	
	public class ControlNode : Node {
		
		public bool active;
		public Node above, right;
		
		public ControlNode(Vector3 _pos, bool _active, float squareSize) : base(_pos) {
			active = _active;
			above = new Node(position + Vector3.forward * squareSize/2f);
			right = new Node(position + Vector3.right * squareSize/2f);
		}
	}
}
