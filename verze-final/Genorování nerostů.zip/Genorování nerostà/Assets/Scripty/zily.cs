﻿using UnityEngine;
using System.Collections;
using System;

public class zily : MonoBehaviour {

	public int width;
	public int height;
	public int sousedskePravidlo;

	public string seed;
	public bool pouzijSeed;






	[Range(0,100)]
	public int procentoZaplneni;

	int[,] zila;

	void Start(){
		GeneratorZil ();
	}

	/*void Update()
	{
		if (Input.GetMouseButtonDown (0))
			GeneratorZil ();
	}*/

	void GeneratorZil() {
		zila= new int[width,height];
		RandomFillmap ();

		for (int i=0; i<5; i++){
			Pravidla();
		}



		Mesh_generator meshGen = GetComponent<Mesh_generator>();
		meshGen.GenerateMesh(zila,6f);
	}

	void RandomFillmap() {
		if (pouzijSeed) {
			seed = seed.GetHashCode()+Time.time.ToString ();
		}

		System.Random nahoda = new System.Random (seed.GetHashCode());

		for (int x=0; x<width; x++) {
			for (int y=0; y<height; y++)
			{
				zila[x,y]= (nahoda.Next(0,100)<procentoZaplneni)? 1:0; 
			}
		}
	}

	void Pravidla()
	{
		for (int x=0; x<width; x++) {
			for (int y=0; y<height; y++) {
				int pocetsousedu = GetPocetSousedu(x,y);

				if(pocetsousedu>sousedskePravidlo)
					zila[x,y]=1;
				else if(pocetsousedu<sousedskePravidlo)
					zila[x,y]=0;
			}
		}
	}

	int GetPocetSousedu(int gridX, int gridY)
	{
		int pocet = 0;
		for (int Xsoused=gridX-1; Xsoused<=gridX+1; Xsoused++) {
			for (int Ysoused=gridY-1; Ysoused<=gridY+1; Ysoused++) {
				if(Xsoused>=0 && Xsoused<width && Ysoused>=0 && Ysoused<height)
				{
					if(Xsoused!=gridX || Ysoused!=gridY)
					{
						pocet += zila[Xsoused,Ysoused];
					}
				}
				else
					pocet++;
			}
		}
		return pocet;
	}

	void OnDrawGizmos()
	{
		/*
		if (zila != null) {
			
			for (int x=0; x<width; x++) {
				for (int y=0; y<height; y++)
				{
					Gizmos.color = (zila[x,y]==1)?Color.white:Color.black;
					Vector3 pos = new Vector3(-width/2+x+.5f,0,-height/2+y+.5f);
					Gizmos.DrawCube(pos,Vector3.one);
					
				}
			}
		}
		*/
	}
}
